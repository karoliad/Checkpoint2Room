package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

//    Scanner som leser inn linje og deler inn ved &
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter rooms in the apartment");
        String rooms = scanner.nextLine();
        String[] roomsSplit = rooms.split("[\\s &]");
        System.out.println(Arrays.toString(roomsSplit));

        Room[] myApartment = new Room[ roomsSplit.length];
        Room room = new Room(roomsSplit[0]);

   }



//        Room[] myApartment = new Room[5];
//        System.out.println(Arrays.toString(roomsSplit));


//
//        Room[] myApartment = {
//                new Room("kitchen", 5,4),
//                new Room ("BedRoom", 5,8,),
//                new Room ("LivingRoom", 6,8)
//        };

//
//        String room = roomsSplit[0].split(" ");

//        Må caste string-elementer i arrayen til objektarrayen


    }
